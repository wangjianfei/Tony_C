#include<stdio.h>

int main()
{
  printf("hello world\n0");
  return 0;
}
